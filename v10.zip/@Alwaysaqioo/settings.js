global.prefa = ['','!','.',',','🐤','🗿']

global.owner = ['628xxx']
global.namaowner = ['Alwaysaqioo']
global.botname = 'Alwaysaqioo-Botz'
global.baileys1 = require('@whiskeysockets/baileys') 
global.sticker1 = "Alwaysaqioo Gacor"
global.sticker2 = "🌜"
global.adana = '6288708247447'
global.aqris = 'https://telegra.ph/file/1701509104e6531c8a4d1.jpg'
global.aovo = '6288708247447'
global.agopay = '6288708247447'